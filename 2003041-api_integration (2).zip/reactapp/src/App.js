import React, { useState, useEffect } from 'react';
import "./App.css";
function CovidTable() {
  const [covidData, setCovidData] = useState([]);

  useEffect(() => {
    fetch('https://api.rootnet.in/covid19-in/stats/latest')
      .then(response => response.json())
      .then(data => setCovidData(data.data.regional))
      .catch(error => console.error(error));
  }, []);

  return (
    <div class='x'>
    <table class='styled-table' >
      <thead>
        <tr>
          <th>State</th>
          <th>Confirmed Cases</th>
          <th>Recovered Cases</th>
          <th>Deaths</th>
        </tr>
      </thead>
      <tbody>
        {covidData.map(state => (
          <tr key={state.loc}>
            <td>{state.loc}</td>
            <td>{state.totalConfirmed}</td>
            <td>{state.discharged}</td>
            <td>{state.deaths}</td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  );
}

export default CovidTable;


